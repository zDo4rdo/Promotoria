# 📦 Promotoria PWA — Como instalar no celular

## O que você vai precisar (tudo gratuito)
- Conta no **GitHub**: https://github.com
- Conta no **Vercel**: https://vercel.com

---

## PASSO 1 — Criar conta no GitHub
1. Acesse https://github.com e clique em **Sign up**
2. Crie sua conta (pode usar qualquer e-mail)

---

## PASSO 2 — Subir o projeto no GitHub
1. No GitHub, clique em **"New repository"** (botão verde)
2. Nome: `promotoria-pwa`
3. Deixe como **Public**
4. Clique em **Create repository**
5. Na próxima tela, clique em **"uploading an existing file"**
6. **Arraste todos os arquivos desta pasta** para a área de upload
   - ⚠️ Inclua as subpastas: `src/` e `public/`
7. Clique em **Commit changes**

---

## PASSO 3 — Publicar no Vercel
1. Acesse https://vercel.com e clique em **Sign Up with GitHub**
2. Clique em **"Add New Project"**
3. Selecione o repositório `promotoria-pwa`
4. Clique em **Deploy** (não muda nada, deixa tudo padrão)
5. Aguarde ~1 minuto
6. O Vercel vai te dar um link tipo: `promotoria-pwa.vercel.app`

---

## PASSO 4 — Instalar no celular Android
1. Abra o link no **Chrome** do celular
2. O Chrome vai mostrar um banner **"Adicionar à tela inicial"** — toque nele
3. Se não aparecer: toque nos **3 pontinhos** → **"Adicionar à tela inicial"**
4. Pronto! O app aparece no menu igual qualquer outro app ✅

## PASSO 4 — Instalar no iPhone (iOS)
1. Abra o link no **Safari**
2. Toque no ícone de **compartilhar** (quadrado com seta para cima)
3. Role e toque em **"Adicionar à Tela de Início"**
4. Toque em **Adicionar** ✅

---

## ✅ Funcionalidades do PWA
- Funciona **offline** (sem internet)
- Dados salvos no próprio celular
- Abre em tela cheia, sem barra do navegador
- Ícone bonito na tela inicial
- Leve e rápido

---

## ❓ Dúvidas comuns

**"Preciso pagar alguma coisa?"**
Não. GitHub e Vercel têm planos gratuitos suficientes para isso.

**"Outros podem acessar meu app?"**
Sim, o link é público — mas os dados ficam só no celular de quem usa.

**"Como atualizar o app?"**
Edite os arquivos no GitHub → o Vercel republica automaticamente em ~1 min → na próxima abertura o app atualiza sozinho.
