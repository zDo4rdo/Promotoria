import { useState, useEffect } from "react";

// ─── STORAGE ─────────────────────────────────────────────────────────────────
const KEY = "prom_v2";
const init = { produtos: [], visitas: [], tarefas: [], rupturas: [], checklistsSemana: {} };
const load = () => { try { return { ...init, ...JSON.parse(localStorage.getItem(KEY) || "{}") }; } catch { return init; } };
const save = (d) => localStorage.setItem(KEY, JSON.stringify(d));

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const hojeISO = () => new Date().toISOString().split("T")[0];

const diasRestantes = (val) => {
  const h = new Date(); h.setHours(0,0,0,0);
  return Math.ceil((new Date(val + "T00:00:00") - h) / 86400000);
};

const fmtData = (iso) => new Date(iso + "T00:00:00").toLocaleDateString("pt-BR");

const semanaISO = () => {
  const d = new Date();
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  const seg = new Date(new Date().setDate(diff));
  return seg.toISOString().split("T")[0];
};

const statusValidade = (dias) => {
  if (dias < 0)   return { label: "VENCIDO",    cor: "#ff3b3b", fundo: "#2d0000", emoji: "💀" };
  if (dias === 0) return { label: "VENCE HOJE", cor: "#ff7043", fundo: "#2d1200", emoji: "🔥" };
  if (dias <= 3)  return { label: `${dias}d`,   cor: "#ff9800", fundo: "#2d1a00", emoji: "⚠️" };
  if (dias <= 7)  return { label: `${dias}d`,   cor: "#ffd600", fundo: "#2d2600", emoji: "⏰" };
  if (dias <= 30) return { label: `${dias}d`,   cor: "#69f0ae", fundo: "#002d18", emoji: "📅" };
  return              { label: `${dias}d`,      cor: "#40c4ff", fundo: "#002233", emoji: "✅" };
};

const diaDaSemana = () => new Date().toLocaleDateString("pt-BR", { weekday: "long" });
const dataHoje    = () => new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });

// ─── APP ROOT ─────────────────────────────────────────────────────────────────
export default function App() {
  const [data, setData]   = useState(load);
  const [tela, setTela]   = useState("home");
  const [toast, setToast] = useState(null);

  useEffect(() => save(data), [data]);

  const upd = (k, v) => setData(d => ({ ...d, [k]: v }));
  const msg = (txt, tipo = "ok") => { setToast({ txt, tipo }); setTimeout(() => setToast(null), 2500); };

  const vencidos   = data.produtos.filter(p => diasRestantes(p.validade) < 0);
  const alertas    = data.produtos.filter(p => { const d = diasRestantes(p.validade); return d >= 0 && d <= 7; });
  const semAtual   = semanaISO();
  const checklist  = data.checklistsSemana[semAtual] || {};
  const totalCheck = data.produtos.length;
  const feitosCheck = Object.values(checklist).filter(Boolean).length;
  const checkCompleto = totalCheck > 0 && feitosCheck >= totalCheck;

  const telas = {
    home:      <Home vencidos={vencidos} alertas={alertas} data={data} setTela={setTela} checkCompleto={checkCompleto} feitosCheck={feitosCheck} totalCheck={totalCheck} semAtual={semAtual} />,
    checklist: <ChecklistSemanal produtos={data.produtos} checklist={checklist} semAtual={semAtual} upd={upd} data={data} msg={msg} setTela={setTela} />,
    produtos:  <Produtos produtos={data.produtos} upd={v => upd("produtos", v)} msg={msg} />,
    visitas:   <Visitas visitas={data.visitas} upd={v => upd("visitas", v)} msg={msg} />,
    tarefas:   <Tarefas tarefas={data.tarefas} upd={v => upd("tarefas", v)} msg={msg} />,
    rupturas:  <Rupturas rupturas={data.rupturas} upd={v => upd("rupturas", v)} msg={msg} />,
    relatorio: <Relatorio data={data} vencidos={vencidos} alertas={alertas} msg={msg} />,
  };

  return (
    <div style={S.app}>
      <div style={S.header}>
        {tela !== "home" ? (
          <button style={S.back} onClick={() => setTela("home")}>← Voltar</button>
        ) : (
          <div style={S.logoWrap}>
            <span style={S.logoEmoji}>📦</span>
            <span style={S.logoTxt}>PROMOTORIA</span>
          </div>
        )}
        <div style={S.headerRight}>
          <div style={S.diaHoje}>{diaDaSemana()}</div>
          <div style={S.dataHoje}>{dataHoje()}</div>
        </div>
      </div>

      {(vencidos.length > 0 || alertas.length > 0) && tela === "home" && (
        <div style={S.alertBar}>
          {vencidos.length > 0 && <span style={S.alertChip("#ff3b3b")}>💀 {vencidos.length} vencido{vencidos.length > 1 ? "s" : ""}</span>}
          {alertas.length > 0  && <span style={S.alertChip("#ffd600")}>⏰ {alertas.length} vencem em até 7 dias</span>}
        </div>
      )}

      <div style={S.content}>{telas[tela]}</div>

      {toast && (
        <div style={{ ...S.toast, background: toast.tipo === "ok" ? "#1a3a1a" : "#3a1a1a", borderColor: toast.tipo === "ok" ? "#69f0ae" : "#ff3b3b" }}>
          {toast.tipo === "ok" ? "✅" : "❌"} {toast.txt}
        </div>
      )}
    </div>
  );
}

// ─── HOME ─────────────────────────────────────────────────────────────────────
function Home({ vencidos, alertas, data, setTela, checkCompleto, feitosCheck, totalCheck }) {
  const pendentes   = data.tarefas.filter(t => !t.concluida).length;
  const ruptAberta  = data.rupturas.filter(r => !r.resolvida).length;
  const visitasHoje = data.visitas.filter(v => v.data === hojeISO()).length;
  const pct = totalCheck > 0 ? Math.round((feitosCheck / totalCheck) * 100) : 0;

  const menu = [
    { icon: "📦", label: "Produtos & Validades", sub: `${data.produtos.length} produto${data.produtos.length !== 1 ? "s" : ""}`, tela: "produtos", cor: "#40c4ff" },
    { icon: "🏪", label: "Visitas",              sub: `${visitasHoje} hoje`,                                                     tela: "visitas",  cor: "#69f0ae" },
    { icon: "✅", label: "Tarefas",              sub: `${pendentes} pendente${pendentes !== 1 ? "s" : ""}`,                      tela: "tarefas",  cor: "#ce93d8" },
    { icon: "🚨", label: "Rupturas",             sub: `${ruptAberta} aberta${ruptAberta !== 1 ? "s" : ""}`,                      tela: "rupturas", cor: "#ff7043" },
    { icon: "📊", label: "Relatório",            sub: "Copiar para WhatsApp",                                                    tela: "relatorio",cor: "#80cbc4" },
  ];

  return (
    <div>
      <div style={S.bemVindo}>
        <div style={S.bemVindoTxt}>Olá, promotor! 👋</div>
        <div style={S.bemVindoSub}>O que vamos fazer hoje?</div>
      </div>

      {/* CARD CHECKLIST — DESTAQUE MÁXIMO */}
      <div style={{ ...S.checkCard, borderColor: checkCompleto ? "#69f0ae" : "#ffd600" }} onClick={() => setTela("checklist")}>
        <div style={S.checkCardTop}>
          <div style={{ flex: 1 }}>
            <div style={S.checkCardBadge}>
              {checkCompleto ? "✅ SEMANA CONCLUÍDA" : "📋 CHECKLIST SEMANAL DE VALIDADE"}
            </div>
            <div style={S.checkCardTitulo}>
              {checkCompleto
                ? "Todos os produtos conferidos!"
                : totalCheck === 0
                  ? "Cadastre produtos para começar"
                  : `${feitosCheck} de ${totalCheck} produto${totalCheck !== 1 ? "s" : ""} conferido${feitosCheck !== 1 ? "s" : ""}`}
            </div>
            {!checkCompleto && totalCheck > 0 && (
              <div style={S.checkCardCTA}>Toque para conferir agora →</div>
            )}
          </div>
          <div style={{ ...S.checkPct, color: checkCompleto ? "#69f0ae" : "#ffd600" }}>
            {pct}%
          </div>
        </div>
        {totalCheck > 0 && (
          <div style={S.progressBar}>
            <div style={{ ...S.progressFill, width: `${pct}%`, background: checkCompleto ? "#69f0ae" : "#ffd600" }} />
          </div>
        )}
      </div>

      <div style={S.menuGrid}>
        {menu.map(m => (
          <button key={m.tela} style={{ ...S.menuBtn, borderTop: `3px solid ${m.cor}` }} onClick={() => setTela(m.tela)}>
            <span style={S.menuIcon}>{m.icon}</span>
            <span style={S.menuLabel}>{m.label}</span>
            <span style={{ ...S.menuSub, color: m.cor }}>{m.sub}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── CHECKLIST SEMANAL ────────────────────────────────────────────────────────
function ChecklistSemanal({ produtos, checklist, semAtual, upd, data, msg, setTela }) {
  const marcar = (id) => {
    const novo = { ...checklist, [id]: !checklist[id] };
    upd("checklistsSemana", { ...data.checklistsSemana, [semAtual]: novo });
  };

  const feitos    = Object.values(checklist).filter(Boolean).length;
  const total     = produtos.length;
  const pct       = total > 0 ? Math.round((feitos / total) * 100) : 0;
  const completo  = total > 0 && feitos >= total;
  const ordenados = [...produtos].sort((a, b) => diasRestantes(a.validade) - diasRestantes(b.validade));

  return (
    <div>
      <div style={S.telaHeader}>
        <h2 style={S.telaTitulo}>📋 Checklist Semanal</h2>
        <div style={S.telaSubtitulo}>Confira as validades 1× por semana</div>
      </div>

      <div style={{ ...S.checkCard, borderColor: completo ? "#69f0ae" : "#ffd600", cursor: "default" }}>
        <div style={S.checkCardTop}>
          <div>
            <div style={S.checkCardTitulo}>{completo ? "✅ Semana concluída!" : "Progresso desta semana"}</div>
            <div style={{ color: "#666", fontSize: 12 }}>
              {total === 0 ? "Nenhum produto cadastrado" : `${feitos} de ${total} conferidos — semana de ${fmtData(semAtual)}`}
            </div>
          </div>
          <div style={{ ...S.checkPct, color: completo ? "#69f0ae" : "#ffd600" }}>{pct}%</div>
        </div>
        {total > 0 && (
          <div style={S.progressBar}>
            <div style={{ ...S.progressFill, width: `${pct}%`, background: completo ? "#69f0ae" : "#ffd600" }} />
          </div>
        )}
      </div>

      <div style={S.dica}>
        💡 <strong>Como usar:</strong> Toque no produto ao conferir a validade na gôndola. O check some na próxima semana automaticamente.
      </div>

      {total === 0 && (
        <div style={S.vazio}>
          <div style={{ fontSize: 48 }}>📦</div>
          <div>Nenhum produto cadastrado</div>
          <button style={{ ...S.btnFull("#40c4ff"), marginTop: 12 }} onClick={() => setTela("produtos")}>Cadastrar produtos</button>
        </div>
      )}

      {ordenados.map(p => {
        const dias   = diasRestantes(p.validade);
        const st     = statusValidade(dias);
        const marcado = !!checklist[p.id];
        return (
          <button key={p.id}
            style={{ ...S.checkItem, ...(marcado ? S.checkItemFeito : {}), ...(dias < 0 && !marcado ? S.checkItemUrgente : {}) }}
            onClick={() => marcar(p.id)}
          >
            <div style={{ ...S.checkBox, ...(marcado ? S.checkBoxFeito : {}) }}>
              {marcado && "✓"}
            </div>
            <div style={S.checkInfo}>
              <div style={{ fontWeight: 700, fontSize: 15, color: marcado ? "#555" : "#fff", textDecoration: marcado ? "line-through" : "none" }}>
                {st.emoji} {p.nome}
              </div>
              <div style={{ fontSize: 12, color: "#777", marginTop: 2 }}>
                {p.local && `${p.local} · `}Val: {fmtData(p.validade)}{p.lote && ` · Lote: ${p.lote}`}
              </div>
            </div>
            <div style={{ ...S.valBadge, color: st.cor, background: st.fundo, opacity: marcado ? 0.4 : 1 }}>
              {st.label}
            </div>
          </button>
        );
      })}

      {completo && (
        <div style={S.celebracao}>
          🎉 Parabéns! Checklist da semana 100% concluído!
        </div>
      )}
    </div>
  );
}

// ─── PRODUTOS ─────────────────────────────────────────────────────────────────
function Produtos({ produtos, upd, msg }) {
  const [form, setForm]     = useState({ nome: "", validade: "", lote: "", local: "", qtd: "" });
  const [filtro, setFiltro] = useState("todos");
  const [expandido, setExpandido] = useState(null);
  const f = (k, v) => setForm(s => ({ ...s, [k]: v }));

  const salvar = () => {
    if (!form.nome.trim() || !form.validade) { msg("Preencha nome e validade", "err"); return; }
    upd([...produtos, { ...form, id: Date.now(), adicionadoEm: hojeISO() }]);
    setForm({ nome: "", validade: "", lote: "", local: "", qtd: "" });
    msg("Produto cadastrado!");
  };
  const remover = (id) => { upd(produtos.filter(p => p.id !== id)); msg("Removido"); };

  const lista = [...produtos].filter(p => {
    const d = diasRestantes(p.validade);
    if (filtro === "vencidos") return d < 0;
    if (filtro === "urgente")  return d >= 0 && d <= 7;
    if (filtro === "ok")       return d > 7;
    return true;
  }).sort((a, b) => diasRestantes(a.validade) - diasRestantes(b.validade));

  return (
    <div>
      <div style={S.telaHeader}><h2 style={S.telaTitulo}>📦 Produtos & Validades</h2></div>

      <div style={S.card}>
        <div style={S.cardTitulo}>➕ Cadastrar Produto</div>
        <input style={S.inp} placeholder="Nome do produto *" value={form.nome} onChange={e => f("nome", e.target.value)} />
        <div style={S.row}>
          <div style={{ flex: 1 }}>
            <div style={S.labelInp}>Validade *</div>
            <input type="date" style={S.inp} value={form.validade} onChange={e => f("validade", e.target.value)} />
          </div>
          <input style={{ ...S.inp, flex: 1 }} placeholder="Lote" value={form.lote} onChange={e => f("lote", e.target.value)} />
        </div>
        <div style={S.row}>
          <input style={{ ...S.inp, flex: 2 }} placeholder="Seção / Local (ex: Lácteos, G3)" value={form.local} onChange={e => f("local", e.target.value)} />
          <input style={{ ...S.inp, flex: 1 }} placeholder="Qtd" value={form.qtd} onChange={e => f("qtd", e.target.value)} />
        </div>
        <button style={S.btnFull("#40c4ff")} onClick={salvar}>Cadastrar</button>
      </div>

      <div style={S.filtros}>
        {[["todos","Todos"], ["vencidos","💀 Vencidos"], ["urgente","⏰ ≤7 dias"], ["ok","✅ OK"]].map(([v, l]) => (
          <button key={v} style={{ ...S.filtroBtn, ...(filtro === v ? S.filtroBtnAtivo : {}) }} onClick={() => setFiltro(v)}>{l}</button>
        ))}
        <span style={S.contagem}>{lista.length} item{lista.length !== 1 ? "s" : ""}</span>
      </div>

      {lista.length === 0 && <div style={S.vazio}><div style={{ fontSize: 40 }}>🔍</div>Nenhum produto</div>}

      {lista.map(p => {
        const dias  = diasRestantes(p.validade);
        const st    = statusValidade(dias);
        const aberto = expandido === p.id;
        return (
          <div key={p.id} style={{ ...S.item, ...(dias < 0 ? { borderLeft: "3px solid #ff3b3b" } : dias <= 7 ? { borderLeft: "3px solid #ffd600" } : {}) }}>
            <button style={S.itemMain} onClick={() => setExpandido(aberto ? null : p.id)}>
              <div style={{ flex: 1, textAlign: "left" }}>
                <div style={S.itemNome}>{st.emoji} {p.nome}</div>
                <div style={S.itemSub}>{p.local || "Sem seção"}{p.lote ? ` · Lote: ${p.lote}` : ""}</div>
              </div>
              <div style={{ ...S.valBadge, color: st.cor, background: st.fundo }}>{st.label}</div>
              <span style={{ color: "#555", fontSize: 12, marginLeft: 6 }}>{aberto ? "▲" : "▼"}</span>
            </button>
            {aberto && (
              <div style={S.itemDetalhe}>
                <div style={S.detalheRow}><span>📅 Validade</span><strong>{fmtData(p.validade)}</strong></div>
                {p.lote  && <div style={S.detalheRow}><span>🏷 Lote</span><strong>{p.lote}</strong></div>}
                {p.local && <div style={S.detalheRow}><span>📍 Local</span><strong>{p.local}</strong></div>}
                {p.qtd   && <div style={S.detalheRow}><span>🔢 Qtd</span><strong>{p.qtd}</strong></div>}
                <button style={S.btnRemover} onClick={() => remover(p.id)}>🗑 Remover produto</button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── VISITAS ──────────────────────────────────────────────────────────────────
function Visitas({ visitas, upd, msg }) {
  const [form, setForm] = useState({ loja: "", data: hojeISO(), obs: "" });
  const f = (k, v) => setForm(s => ({ ...s, [k]: v }));

  const salvar = () => {
    if (!form.loja.trim()) { msg("Digite o nome da loja", "err"); return; }
    upd([...visitas, { ...form, id: Date.now() }]);
    setForm({ loja: "", data: hojeISO(), obs: "" });
    msg("Visita registrada!");
  };
  const remover = (id) => upd(visitas.filter(v => v.id !== id));
  const ordenadas = [...visitas].sort((a, b) => b.data.localeCompare(a.data));

  return (
    <div>
      <div style={S.telaHeader}><h2 style={S.telaTitulo}>🏪 Registrar Visita</h2></div>
      <div style={S.card}>
        <input style={S.inp} placeholder="Nome da loja / ponto de venda *" value={form.loja} onChange={e => f("loja", e.target.value)} />
        <div>
          <div style={S.labelInp}>Data da visita</div>
          <input type="date" style={S.inp} value={form.data} onChange={e => f("data", e.target.value)} />
        </div>
        <input style={S.inp} placeholder="Observações (opcional)" value={form.obs} onChange={e => f("obs", e.target.value)} />
        <button style={S.btnFull("#69f0ae")} onClick={salvar}>✓ Registrar Visita</button>
      </div>

      <div style={S.cardTitulo2}>Histórico ({visitas.length})</div>
      {ordenadas.length === 0 && <div style={S.vazio}><div style={{ fontSize: 40 }}>🏪</div>Nenhuma visita ainda</div>}
      {ordenadas.map(v => (
        <div key={v.id} style={S.item}>
          <div style={S.itemMain}>
            <div style={{ flex: 1, textAlign: "left" }}>
              <div style={S.itemNome}>🏪 {v.loja}</div>
              <div style={S.itemSub}>{fmtData(v.data)}{v.obs ? ` · ${v.obs}` : ""}</div>
            </div>
            <button style={S.btnX} onClick={() => remover(v.id)}>✕</button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── TAREFAS ──────────────────────────────────────────────────────────────────
function Tarefas({ tarefas, upd, msg }) {
  const [form, setForm] = useState({ titulo: "", prioridade: "Normal" });
  const f = (k, v) => setForm(s => ({ ...s, [k]: v }));

  const salvar = () => {
    if (!form.titulo.trim()) { msg("Digite a tarefa", "err"); return; }
    upd([...tarefas, { ...form, id: Date.now(), concluida: false }]);
    setForm({ titulo: "", prioridade: "Normal" });
    msg("Tarefa adicionada!");
  };
  const toggle  = (id) => upd(tarefas.map(t => t.id === id ? { ...t, concluida: !t.concluida } : t));
  const remover = (id) => upd(tarefas.filter(t => t.id !== id));

  const pendentes  = tarefas.filter(t => !t.concluida).sort((a) => (a.prioridade === "Alta" ? -1 : 1));
  const concluidas = tarefas.filter(t => t.concluida);
  const corPrio    = { Alta: "#ff7043", Normal: "#40c4ff", Baixa: "#888" };

  return (
    <div>
      <div style={S.telaHeader}><h2 style={S.telaTitulo}>✅ Tarefas</h2></div>
      <div style={S.card}>
        <input style={S.inp} placeholder="O que precisa fazer? *" value={form.titulo} onChange={e => f("titulo", e.target.value)} onKeyDown={e => e.key === "Enter" && salvar()} />
        <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
          {["Alta", "Normal", "Baixa"].map(p => (
            <button key={p} style={{ ...S.pBtn, borderColor: corPrio[p], color: form.prioridade === p ? corPrio[p] : "#555", background: form.prioridade === p ? corPrio[p] + "22" : "transparent" }} onClick={() => f("prioridade", p)}>{p}</button>
          ))}
        </div>
        <button style={{ ...S.btnFull("#ce93d8"), marginTop: 10 }} onClick={salvar}>+ Adicionar Tarefa</button>
      </div>

      {pendentes.length === 0 && <div style={{ ...S.vazio, color: "#69f0ae" }}><div style={{ fontSize: 40 }}>🎉</div>Tudo feito!</div>}

      {pendentes.map(t => (
        <div key={t.id} style={{ ...S.item, borderLeft: `3px solid ${corPrio[t.prioridade]}` }}>
          <div style={S.itemMain}>
            <button style={S.checkBox2} onClick={() => toggle(t.id)} />
            <div style={{ flex: 1, textAlign: "left" }}>
              <div style={S.itemNome}>{t.titulo}</div>
              <div style={{ ...S.itemSub, color: corPrio[t.prioridade] }}>{t.prioridade}</div>
            </div>
            <button style={S.btnX} onClick={() => remover(t.id)}>✕</button>
          </div>
        </div>
      ))}

      {concluidas.length > 0 && (
        <>
          <div style={S.cardTitulo2}>Concluídas ({concluidas.length})</div>
          {concluidas.map(t => (
            <div key={t.id} style={{ ...S.item, opacity: 0.4 }}>
              <div style={S.itemMain}>
                <button style={{ ...S.checkBox2, background: "#69f0ae22", borderColor: "#69f0ae", color: "#69f0ae", fontSize: 13 }} onClick={() => toggle(t.id)}>✓</button>
                <div style={{ flex: 1, textDecoration: "line-through", color: "#555", fontSize: 14, textAlign: "left" }}>{t.titulo}</div>
                <button style={S.btnX} onClick={() => remover(t.id)}>✕</button>
              </div>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

// ─── RUPTURAS ─────────────────────────────────────────────────────────────────
function Rupturas({ rupturas, upd, msg }) {
  const [form, setForm] = useState({ produto: "", loja: "", motivo: "" });
  const f = (k, v) => setForm(s => ({ ...s, [k]: v }));

  const salvar = () => {
    if (!form.produto.trim() || !form.loja.trim()) { msg("Produto e loja obrigatórios", "err"); return; }
    upd([...rupturas, { ...form, id: Date.now(), data: hojeISO(), resolvida: false }]);
    setForm({ produto: "", loja: "", motivo: "" });
    msg("Ruptura registrada!");
  };
  const resolver = (id) => { upd(rupturas.map(r => r.id === id ? { ...r, resolvida: true } : r)); msg("Marcado como resolvido!"); };
  const remover  = (id) => upd(rupturas.filter(r => r.id !== id));

  const abertas    = rupturas.filter(r => !r.resolvida);
  const resolvidas = rupturas.filter(r => r.resolvida);

  return (
    <div>
      <div style={S.telaHeader}><h2 style={S.telaTitulo}>🚨 Rupturas de Estoque</h2></div>
      <div style={S.card}>
        <div style={S.cardTitulo}>Produto em falta?</div>
        <input style={S.inp} placeholder="Qual produto está em falta? *" value={form.produto} onChange={e => f("produto", e.target.value)} />
        <input style={S.inp} placeholder="Em qual loja? *" value={form.loja} onChange={e => f("loja", e.target.value)} />
        <input style={S.inp} placeholder="Motivo / observação (opcional)" value={form.motivo} onChange={e => f("motivo", e.target.value)} />
        <button style={S.btnFull("#ff7043")} onClick={salvar}>🚨 Registrar Ruptura</button>
      </div>

      {abertas.length === 0 && <div style={{ ...S.vazio, color: "#69f0ae" }}><div style={{ fontSize: 40 }}>✅</div>Sem rupturas abertas!</div>}

      {abertas.map(r => (
        <div key={r.id} style={{ ...S.item, borderLeft: "3px solid #ff7043" }}>
          <div style={S.itemMain}>
            <div style={{ flex: 1, textAlign: "left" }}>
              <div style={S.itemNome}>🚨 {r.produto}</div>
              <div style={S.itemSub}>{r.loja} · {fmtData(r.data)}{r.motivo ? ` · ${r.motivo}` : ""}</div>
            </div>
            <button style={{ padding: "6px 12px", background: "#69f0ae22", color: "#69f0ae", border: "1px solid #69f0ae55", borderRadius: 8, cursor: "pointer", fontSize: 12, fontWeight: 700 }} onClick={() => resolver(r.id)}>Resolver</button>
            <button style={S.btnX} onClick={() => remover(r.id)}>✕</button>
          </div>
        </div>
      ))}

      {resolvidas.length > 0 && (
        <>
          <div style={S.cardTitulo2}>Resolvidas ({resolvidas.length})</div>
          {resolvidas.map(r => (
            <div key={r.id} style={{ ...S.item, opacity: 0.35 }}>
              <div style={S.itemMain}>
                <div style={{ flex: 1, textAlign: "left" }}>
                  <div style={{ ...S.itemNome, textDecoration: "line-through" }}>{r.produto} · {r.loja}</div>
                </div>
                <button style={S.btnX} onClick={() => remover(r.id)}>✕</button>
              </div>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

// ─── RELATÓRIO ────────────────────────────────────────────────────────────────
function Relatorio({ data, vencidos, alertas, msg }) {
  const visitasHoje = data.visitas.filter(v => v.data === hojeISO());
  const ruptAbertas = data.rupturas.filter(r => !r.resolvida);
  const pendentes   = data.tarefas.filter(t => !t.concluida);
  const concluidas  = data.tarefas.filter(t => t.concluida);

  const texto = [
    `📊 RELATÓRIO DE PROMOTORIA`,
    `📅 ${dataHoje().toUpperCase()}`,
    ``,
    `🏪 VISITAS HOJE: ${visitasHoje.length}`,
    ...visitasHoje.map(v => `  • ${v.loja}`),
    ``,
    `📦 VALIDADES:`,
    `  💀 Vencidos: ${vencidos.length}`,
    ...vencidos.map(p => `     • ${p.nome}${p.local ? ` (${p.local})` : ""}`),
    `  ⏰ Vencem em 7 dias: ${alertas.length}`,
    ...alertas.map(p => `     • ${p.nome} — ${diasRestantes(p.validade)}d`),
    ``,
    `✅ TAREFAS: ${concluidas.length} feitas / ${pendentes.length} pendentes`,
    ...pendentes.map(t => `  • [${t.prioridade}] ${t.titulo}`),
    ``,
    `🚨 RUPTURAS ABERTAS: ${ruptAbertas.length}`,
    ...ruptAbertas.map(r => `  • ${r.produto} — ${r.loja}`),
  ].join("\n");

  const copiar = () => { navigator.clipboard.writeText(texto); msg("Copiado! Cole no WhatsApp 📲"); };

  const cards = [
    { icon: "🏪", label: "Visitas hoje",      val: visitasHoje.length,  cor: "#69f0ae" },
    { icon: "💀", label: "Vencidos",           val: vencidos.length,     cor: "#ff3b3b" },
    { icon: "⏰", label: "Vencem em 7 dias",   val: alertas.length,      cor: "#ffd600" },
    { icon: "📌", label: "Tarefas pendentes",  val: pendentes.length,    cor: "#ce93d8" },
    { icon: "✅", label: "Tarefas feitas",     val: concluidas.length,   cor: "#69f0ae" },
    { icon: "🚨", label: "Rupturas abertas",   val: ruptAbertas.length,  cor: "#ff7043" },
  ];

  return (
    <div>
      <div style={S.telaHeader}><h2 style={S.telaTitulo}>📊 Relatório do Dia</h2></div>

      <div style={S.resumoGrid}>
        {cards.map(c => (
          <div key={c.label} style={{ ...S.resumoCard, borderTop: `3px solid ${c.cor}` }}>
            <span style={{ fontSize: 22 }}>{c.icon}</span>
            <span style={{ fontSize: 24, fontWeight: 900, color: c.cor }}>{c.val}</span>
            <span style={{ fontSize: 10, color: "#777", textAlign: "center", lineHeight: 1.3 }}>{c.label}</span>
          </div>
        ))}
      </div>

      <button style={{ ...S.btnFull("#69f0ae"), fontSize: 16, padding: 16, marginBottom: 16 }} onClick={copiar}>
        📋 Copiar para WhatsApp
      </button>

      <div style={{ background: "#0a0a0a", border: "1px solid #1a1a1a", borderRadius: 12, padding: 16 }}>
        <pre style={{ fontSize: 12, color: "#888", whiteSpace: "pre-wrap", margin: 0, lineHeight: 1.8 }}>{texto}</pre>
      </div>
    </div>
  );
}

// ─── STYLES ───────────────────────────────────────────────────────────────────
const S = {
  app:         { background: "#0c0c0c", minHeight: "100vh", color: "#e0e0e0", fontFamily: "'Segoe UI', system-ui, sans-serif", maxWidth: 480, margin: "0 auto", position: "relative" },
  header:      { background: "#111", borderBottom: "1px solid #1e1e1e", padding: "14px 18px", display: "flex", justifyContent: "space-between", alignItems: "center" },
  logoWrap:    { display: "flex", alignItems: "center", gap: 8 },
  logoEmoji:   { fontSize: 22 },
  logoTxt:     { fontSize: 18, fontWeight: 900, letterSpacing: 3, color: "#fff", fontFamily: "monospace" },
  back:        { background: "none", border: "none", color: "#40c4ff", fontSize: 15, cursor: "pointer", padding: 0, fontWeight: 600 },
  headerRight: { textAlign: "right" },
  diaHoje:     { color: "#fff", fontSize: 13, fontWeight: 700, textTransform: "capitalize" },
  dataHoje:    { color: "#666", fontSize: 11 },

  alertBar:    { background: "#1a1200", borderBottom: "1px solid #332200", padding: "8px 18px", display: "flex", gap: 10, flexWrap: "wrap" },
  alertChip:   (c) => ({ background: c + "22", color: c, border: `1px solid ${c}44`, borderRadius: 20, padding: "4px 10px", fontSize: 12, fontWeight: 700 }),

  content:     { padding: 16, paddingBottom: 40 },

  bemVindo:    { marginBottom: 16 },
  bemVindoTxt: { fontSize: 20, fontWeight: 800, color: "#fff" },
  bemVindoSub: { color: "#666", fontSize: 14 },

  checkCard:     { background: "#141414", border: "2px solid #333", borderRadius: 16, padding: 18, marginBottom: 16, cursor: "pointer" },
  checkCardTop:  { display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 },
  checkCardBadge:{ fontSize: 10, fontWeight: 900, letterSpacing: 2, color: "#ffd600", marginBottom: 6 },
  checkCardTitulo:{ fontSize: 16, fontWeight: 800, color: "#fff", marginBottom: 4 },
  checkCardCTA:  { color: "#ffd600", fontSize: 12, marginTop: 8, fontWeight: 700 },
  checkPct:      { fontSize: 32, fontWeight: 900 },
  progressBar:   { background: "#1e1e1e", borderRadius: 99, height: 6, marginTop: 12, overflow: "hidden" },
  progressFill:  { height: "100%", borderRadius: 99, transition: "width 0.4s" },

  menuGrid:    { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 },
  menuBtn:     { background: "#141414", border: "1px solid #1e1e1e", borderRadius: 14, padding: "14px 12px", cursor: "pointer", display: "flex", flexDirection: "column", gap: 4, textAlign: "left" },
  menuIcon:    { fontSize: 26 },
  menuLabel:   { color: "#e0e0e0", fontSize: 14, fontWeight: 700 },
  menuSub:     { fontSize: 11, fontWeight: 600 },

  telaHeader:    { marginBottom: 18 },
  telaTitulo:    { fontSize: 20, fontWeight: 900, color: "#fff", margin: 0 },
  telaSubtitulo: { color: "#666", fontSize: 13, marginTop: 4 },

  dica: { background: "#111", border: "1px solid #222", borderRadius: 10, padding: "10px 14px", fontSize: 12, color: "#999", marginBottom: 12 },

  checkItem:        { width: "100%", background: "#141414", border: "1px solid #1e1e1e", borderRadius: 12, padding: "14px 12px", display: "flex", alignItems: "center", gap: 12, marginBottom: 8, cursor: "pointer", textAlign: "left" },
  checkItemFeito:   { background: "#0d0d0d", border: "1px solid #1a1a1a" },
  checkItemUrgente: { border: "1px solid #ff3b3b44", background: "#1a0000" },
  checkBox:         { width: 28, height: 28, borderRadius: 8, border: "2px solid #333", background: "#0c0c0c", display: "flex", alignItems: "center", justifyContent: "center", color: "#69f0ae", fontWeight: 900, flexShrink: 0, fontSize: 14 },
  checkBoxFeito:    { background: "#69f0ae22", borderColor: "#69f0ae" },
  checkInfo:        { flex: 1 },

  card:        { background: "#141414", border: "1px solid #1e1e1e", borderRadius: 16, padding: 18, marginBottom: 16 },
  cardTitulo:  { fontSize: 14, fontWeight: 800, color: "#fff", marginBottom: 12 },
  cardTitulo2: { fontSize: 13, fontWeight: 700, color: "#666", margin: "16px 0 8px 0" },

  inp:      { width: "100%", background: "#0c0c0c", border: "1px solid #252525", borderRadius: 10, padding: "12px 14px", color: "#e0e0e0", fontSize: 14, outline: "none", boxSizing: "border-box", marginBottom: 8 },
  labelInp: { color: "#666", fontSize: 11, marginBottom: 4 },
  row:      { display: "flex", gap: 8 },

  btnFull:  (c) => ({ background: c + "22", color: c, border: `1px solid ${c}55`, borderRadius: 10, padding: "12px 20px", fontSize: 14, fontWeight: 800, cursor: "pointer", display: "block", width: "100%", textAlign: "center" }),

  filtros:       { display: "flex", gap: 6, marginBottom: 12, flexWrap: "wrap", alignItems: "center" },
  filtroBtn:     { background: "#141414", border: "1px solid #252525", color: "#777", borderRadius: 20, padding: "5px 12px", fontSize: 12, cursor: "pointer" },
  filtroBtnAtivo:{ background: "#1a2a3a", color: "#40c4ff", border: "1px solid #40c4ff55" },
  contagem:      { color: "#555", fontSize: 12, marginLeft: "auto" },

  item:       { background: "#141414", border: "1px solid #1e1e1e", borderRadius: 12, marginBottom: 8, overflow: "hidden" },
  itemMain:   { width: "100%", background: "none", border: "none", padding: "14px 12px", display: "flex", alignItems: "center", gap: 10, cursor: "pointer" },
  itemNome:   { color: "#e0e0e0", fontSize: 14, fontWeight: 700 },
  itemSub:    { color: "#666", fontSize: 12, marginTop: 2 },
  itemDetalhe:{ background: "#0c0c0c", borderTop: "1px solid #1e1e1e", padding: "12px 14px" },
  detalheRow: { display: "flex", justifyContent: "space-between", fontSize: 13, color: "#888", marginBottom: 6 },

  valBadge: { borderRadius: 8, padding: "4px 10px", fontSize: 12, fontWeight: 900, letterSpacing: 0.5, whiteSpace: "nowrap" },

  btnRemover: { background: "#2a0000", color: "#ff3b3b", border: "1px solid #ff3b3b33", borderRadius: 8, padding: "8px 14px", cursor: "pointer", fontSize: 12, marginTop: 8, width: "100%" },
  btnX:       { background: "none", border: "none", color: "#444", fontSize: 18, cursor: "pointer", padding: "4px 8px" },

  checkBox2: { width: 26, height: 26, borderRadius: 6, border: "2px solid #333", background: "#0c0c0c", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 13 },

  pBtn: { border: "1px solid", borderRadius: 8, padding: "6px 12px", fontSize: 12, cursor: "pointer", fontWeight: 700 },

  resumoGrid: { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 16 },
  resumoCard: { background: "#141414", border: "1px solid #1e1e1e", borderRadius: 12, padding: "12px 8px", display: "flex", flexDirection: "column", alignItems: "center", gap: 4 },

  celebracao: { background: "#002d18", border: "1px solid #69f0ae44", borderRadius: 14, padding: 18, textAlign: "center", color: "#69f0ae", fontWeight: 800, fontSize: 15, marginTop: 12 },
  vazio:      { textAlign: "center", padding: 32, color: "#555", display: "flex", flexDirection: "column", alignItems: "center", gap: 8 },

  toast: { position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)", border: "1px solid", borderRadius: 12, padding: "12px 20px", fontSize: 14, fontWeight: 700, zIndex: 999, whiteSpace: "nowrap", boxShadow: "0 4px 20px #000a" },
};
